import { combineReducers } from "redux";
import { reducer } from "./reducer";

let rootReducer =combineReducers({
    reducer:reducer
})

export default rootReducer