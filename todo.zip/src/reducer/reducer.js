let initialState = {
  list: [],
};

export let reducer = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_TODO":
      return {
        list: [...state.list, action.payload],
      };
    case "DELETE_TODO":
      state.list.splice(action.payload, 1);
      return {
        list: [...state.list],
      };
    case "DELETE_ALL":
      return {
        list: [],
      };
      case "EDIT_TODO":
      const updatedList = state.list.map((value, index) =>
        index === action.payload.index ? action.payload.newValue : value
      );
      return {
        ...state,
        list: updatedList,
      };
    default:
      return state;
  }
};