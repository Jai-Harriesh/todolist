import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addTodo } from "../actions/actions";

const Todo = () => {
    const [initValue, setinitValue] = useState("")
    console.log("initial value",initValue)
    let dispatch=useDispatch()
  return (
    <div>
      <h1 className="txt-container text-center">TODO LIST</h1>
      <div className="todo-container d-flex justify-content-center my-3">
      <input className="input-box p-2" type="text" placeholder="enter your todo's..." value={initValue} onChange={(event)=>{setinitValue(event.target.value)}}/>
    <button type="button" className="button ms-2" onClick={()=>{dispatch(addTodo(initValue));setinitValue('')}}>
    <span className="button__text">Add Item</span>
    <span className="button__icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" viewBox="0 0 24 24" stroke-width="2" stroke-line-join="round" stroke-line-cap="round" stroke="currentColor" height="24" fill="none" class="svg"><line y2="19" y1="5" x2="12" x1="12"></line><line y2="12" y1="12" x2="19" x1="5"></line></svg></span>
    </button>
    </div>
    </div>
  );
};

export default Todo;