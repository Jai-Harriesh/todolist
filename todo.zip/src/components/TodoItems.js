import React, { useState } from "react";
import { MdDeleteForever, MdEdit, MdSave } from "react-icons/md"; 
import { useDispatch, useSelector } from "react-redux";
import { deleteAll, deleteTodo, editTodo } from "../actions/actions"; 

const TodoItems = () => {
  const todosFromStore = useSelector((store) => store.reducer.list);
  const dispatch = useDispatch();

  // Track the currently edited todo
  const [editIndex, setEditIndex] = useState(null);
  const [editValue, setEditValue] = useState("");

  const handleEditClick = (index, currentValue) => {
    setEditIndex(index); // Set the index of the todo being edited
    setEditValue(currentValue); // Set the current value of the todo for editing
  };

  const handleSaveClick = (index) => {
    dispatch(editTodo(index, editValue)); // Dispatch the action to save the edited todo
    setEditIndex(null); // Reset the edit index after saving
    setEditValue(""); // Clear the edit value
  };

  return (
    <>
      <div className="mt-4 d-flex align-items-center flex-column">
        <h1 className="todo-txt text-center fs-4">YOUR TODO's</h1>

        {todosFromStore.length > 0 ? (
          <>
            {todosFromStore.map((value, index) => (
              <div
                key={index}
                className="w-50 todoitem-container mb-2 d-flex justify-content-between align-items-center"
              >
                {/* Check if the current todo is being edited */}
                {editIndex === index ? (
                  <input
                    type="text"
                    value={editValue}
                    onChange={(event) => setEditValue(event.target.value)} // Update editValue on input change
                   className="edit-field"
                  />
                ) : (
                  <h3 className="todo-item fs-6">{value}</h3>
                )}

                <div>
                  {editIndex === index ? (
                    <button
                      className="save-btn"
                      style={{ padding: "8px" }}
                      onClick={() => handleSaveClick(index)} // Save the edited todo
                    >
                      <MdSave style={{ fontSize: "20px", color: "blue" }} />
                    </button>
                  ) : (
                    <button
                      className="delete-btn"
                      style={{ padding: "8px" }}
                      onClick={() => handleEditClick(index, value)} // Start editing the todo
                    >
                      <MdEdit style={{ fontSize: "20px", color: "green" }} />
                    </button>
                  )}

                  <button
                    className="delete-btn ms-1"
                    style={{ padding: "8px" }}
                    onClick={() => {
                      dispatch(deleteTodo(index));
                    }}
                  >
                    <MdDeleteForever style={{ fontSize: "20px", color: "red" }} />
                  </button>
                </div>
              </div>
            ))}

            <button
              className="deleteAll-btn mt-3"
              style={{ padding: "8px" }}
              onClick={() => {
                dispatch(deleteAll());
              }}
            >
              <MdDeleteForever style={{ fontSize: "20px", color: "red" }} />
              Delete All
            </button>
          </>
        ) : (
          <h5 className="no-todo text-danger">NO TODO TO DISPLAY!</h5>
        )}
      </div>
    </>
  );
};

export default TodoItems;