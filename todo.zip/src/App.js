import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Todo from './components/Todo';
import TodoItems from './components/TodoItems';

function App() {
  return (
    <div className="App">
  <Todo />
  <TodoItems />
    </div>
  );
}

export default App;
