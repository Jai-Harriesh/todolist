export let addTodo=(data)=>{
    return {
        type:"ADD_TODO",
        payload:data
    }
}

export let deleteTodo=(index)=>{
    return {
        type:"DELETE_TODO",
        payload:index
    }
}
export let deleteAll=()=>{
    return {
        type:"DELETE_ALL"
    }
}

export const editTodo = (index, newValue) => {
    return {
      type: "EDIT_TODO",
      payload: {
        index,
        newValue,
      },
    };
  };
  